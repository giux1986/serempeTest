<?php

	

	define("base_path", "http://localhost/serempe/");
	
	spl_autoload_register('myAutoLoader');


	function myAutoLoader($className){

		$url = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];

		if(strpos($url, 'includes') !== false || strpos($url, 'home') !== false  || strpos($url, 'clients') !== false || strpos($url, 'users') !== false  || strpos($url, 'cities') !== false )
		{
			$path 		= "../classes/";
		}
		else
		{
			$path 		= "classes/";
		}
		
		$extension  = ".class.php";
		$fullpath 	= $path . $className . $extension;
		
		if (!file_exists($fullpath)) {
			return false;
		}
		
		include_once $fullpath;
		
	}

	


?>